
public abstract class Person {

	String name;
	String mail;

		
	public Person() {
			// TODO Auto-generated constructor stub
		}
		
	public Person(String name, String mail) {
			this.name = name;
			this.mail = mail;
		}

	public void load(String id) {
			
		}
	
}
